import 'package:flutter/material.dart';
import 'package:iot_project_berry/screens/loading.dart';

void main()=>runApp(myApp());

class myApp extends StatelessWidget {
  const myApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IoT Berry',
      home: Loading(),
    );
  }
}
