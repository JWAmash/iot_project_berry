package com.example.iot_project_berry;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
